module LinkTracker {
    requires javafx.fxml;
    requires javafx.controls;
    opens linktracker;
}