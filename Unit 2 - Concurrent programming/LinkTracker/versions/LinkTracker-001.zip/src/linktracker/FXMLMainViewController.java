package linktracker;


import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import linktracker.model.WebPage;
import linktracker.utils.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FXMLMainViewController {

    @FXML
    private MenuItem mILoad;

    @FXML
    private MenuItem mIExit;

    @FXML
    private MenuItem mIStart;

    @FXML
    private MenuItem mIClear;

    @FXML
    private ListView<String> lvWebPages;

    @FXML
    private ListView<String> lvLinks;

    @FXML
    private Label lblTotalPages;

    @FXML
    private Label lblProcessed;

    @FXML
    private Label lblTotalLinks;

    List<WebPage> webList;
    ObservableList<String> urlList;

    @FXML
    void loadFile(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        Stage stage = new Stage();
        File selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            webList = FileUtils.loadPages(selectedFile.toPath());
        }

        Alert dialog = new Alert(Alert.AlertType.INFORMATION);
        dialog.setHeaderText("File loaded");
        dialog.setContentText(webList.size() + " pages found");
        dialog.initStyle(StageStyle.UTILITY);
        dialog.showAndWait();

        for (WebPage w: webList) {
            urlList.add(w.getUrl());
        }

        lvWebPages.setItems(urlList);

        lblTotalPages.setText(String.valueOf(webList.size()));
    }
}