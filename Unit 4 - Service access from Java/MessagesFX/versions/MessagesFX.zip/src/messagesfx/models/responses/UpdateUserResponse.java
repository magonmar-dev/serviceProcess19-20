package messagesfx.models.responses;

public class UpdateUserResponse extends OkResponse {}
