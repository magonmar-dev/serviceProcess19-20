package messagesfx.models.responses;

public class DeleteMessageResponse extends OkResponse {}
