package messagesfx.models.responses;

public class RegisterResponse extends OkResponse {}
