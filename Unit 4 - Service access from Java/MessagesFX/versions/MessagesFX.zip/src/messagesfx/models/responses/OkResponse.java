package messagesfx.models.responses;

public class OkResponse {

    boolean ok;
    String error;

    public boolean isOk() {
        return ok;
    }

    public String getError() {
        return error;
    }
}
