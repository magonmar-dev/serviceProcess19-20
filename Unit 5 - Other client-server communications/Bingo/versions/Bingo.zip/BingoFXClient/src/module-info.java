module BingoFXClient {
    requires javafx.fxml;
    requires javafx.controls;

    opens bingofxclient;
}